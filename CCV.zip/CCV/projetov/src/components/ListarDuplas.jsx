import React, { useEffect, useState } from 'react';
import Header from './Header';
import './ListarDuplas.css';

const ListarDuplas = () => {
  const [duplas, setDuplas] = useState([]);
  const [etapa, setEtapa] = useState(""); 
  const [categoria, setCategoria] = useState("");
  const [etapasDisponiveis, setEtapasDisponiveis] = useState([]); 
  const categorias = ["45+", "Open"]; 

  useEffect(() => {
    const fetchDuplas = async () => {
      try {
        const url = new URL('http://localhost:3000/duplas');
        if (etapa) url.searchParams.append('etapa', etapa);
        if (categoria) url.searchParams.append('categoria', categoria);

        const response = await fetch(url);
        const data = await response.json();
        setDuplas(data);
      } catch (error) {
        console.error('Erro ao buscar duplas:', error);
      }
    };

    fetchDuplas();
  }, [etapa, categoria]);

  useEffect(() => {
    const fetchEtapas = async () => {
      try {
        const response = await fetch('http://localhost:3000/duplas');
        const data = await response.json();
        const etapas = new Set();
        data.forEach((dupla) => {
          dupla.atleta1.pontuacoesPorEtapa.forEach((p) => etapas.add(p.etapa));
          dupla.atleta2.pontuacoesPorEtapa.forEach((p) => etapas.add(p.etapa));
        });
        setEtapasDisponiveis([...etapas]);
      } catch (error) {
        console.error('Erro ao buscar etapas:', error);
      }
    };

    fetchEtapas();
  }, []);

  const getTituloTabela = () => {
    if (!etapa && !categoria) {
      return "Ranking de todas as etapas e todas as categorias";
    }
    if (etapa && categoria) {
      return `Ranking da etapa ${etapa} e categoria ${categoria}`;
    }
    if (etapa) {
      return `Ranking da etapa ${etapa}`;
    }
    return `Ranking da categoria ${categoria}`;
  };

  return (
    <div className="lista-duplas-container">
      <Header />
      <main className="main-contentL">
        <h2 className="subtitleLD">Bem-vindo à Página de Ranqueamento do Torneio!</h2>
        <p className="texto">Aqui você encontrará a classificação atualizada das duplas...</p>

        <h2 className="subtitleLD">{getTituloTabela()}</h2>

        <div className="filtros">
          <div className="etapa-filtro">
            <label className="filtro" htmlFor="etapa">Filtrar por Etapa: </label>
            <select
              id="etapa"
              value={etapa}
              onChange={(e) => setEtapa(e.target.value)}
            >
              <option value="">Todas</option>
              {etapasDisponiveis.map((etapa, index) => (
                <option key={index} value={etapa}>{etapa}</option>
              ))}
            </select>
          </div>

          <div className="categoria-filtro">
            <label className="filtro" htmlFor="categoria">Filtrar por Categoria: </label>
            <select
              id="categoria"
              value={categoria}
              onChange={(e) => setCategoria(e.target.value)}
            >
              <option value="">Todas</option>
              {categorias.map((cat, index) => (
                <option key={index} value={cat}>{cat}</option>
              ))}
            </select>
          </div>
        </div>

        {duplas.length === 0 ? (
          <p className="mensagem">Não há duplas ranqueadas.</p>
        ) : (
          <table className="ranking-tabela">
            <thead>
              <tr>
                <th>Posição</th>
                <th>Atleta 1</th>
                <th>Atleta 2</th>
                <th>Categoria</th>
                <th>Pontuação</th>
              </tr>
            </thead>
            <tbody>
              {duplas.map((dupla, index) => (
                <tr key={dupla._id}>
                  <td>{index + 1}</td>
                  <td>{dupla.atleta1.nome}</td>
                  <td>{dupla.atleta2.nome}</td>
                  <td>{dupla.categoria}</td>
                  <td>{etapa ? dupla.pontuacaoTotalEtapa : dupla.pontuacaoTotal}</td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </main>
    </div>
  );
};

export default ListarDuplas;