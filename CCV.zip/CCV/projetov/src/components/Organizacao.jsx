import './Organizacao.css';
import Header from './Header';

const Organizacao = () => {

  return (
    <div className="organizacao-container">
        <Header /> {}

      <main className="main-contentO">
        <div className="organizacao-info">
          <div className="organizacao-image">
            <img 
              src="/Imagens/Icon Sol.png" 
              alt="Organização" 
              className="organizacao-img"
            />
          </div>
          
          <div className="organizacao-text">
            <h2>Nosso Objetivo</h2>
            <p>
              A Organização do Circuito Campinense de Vôlei de Praia é formada por um grupo de amigos apaixonados pelo esporte, que se uniram com o objetivo de fomentar o vôlei de praia em Campina Grande. Nosso propósito é promover a prática esportiva, incentivar a convivência saudável e criar um ambiente acolhedor para todos os apaixonados pelo esporte. Acreditamos que o esporte é uma excelente ferramenta para o desenvolvimento físico, social e emocional dos participantes, e queremos tornar o vôlei de praia uma referência na cidade.
            </p>
          </div>
        </div>

        <div className="contato-buttons">
          <a 
            href="https://wa.me/5583981709769" 
            target="_blank" 
            rel="noopener noreferrer" 
            className="btn-contato whatsapp-btn"
          >
            Contate-nos via WhatsApp
          </a>
          <a 
            href="mailto:he.fla3@gmail.com" 
            className="btn-contato email-btn"
          >
            Contate-nos via Email
          </a>
        </div>
      </main>
    </div>
  );
};

export default Organizacao;
