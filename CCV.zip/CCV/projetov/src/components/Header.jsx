import React from 'react';
import { Link } from 'react-router-dom';
import './Header.css';

const Header = () => {
  return (
    <header className="header">
      <div className="logo">
        <Link to="/" className="logo-link">
          <p>Circuito Campinense</p>
        </Link>
      </div>
      <nav>
        <ul className="nav-list">
          <li>
            <Link to="/login" className="btn-header">
              Login
            </Link>
          </li>
          <li>
            <Link to="/listar" className="btn-header">
              Ranking
            </Link>
          </li>
          <li>
            <Link to="/galeria" className="btn-header">
              Galeria
            </Link>
          </li>
          <li>
            <Link to="/torneios" className="btn-header">
              Torneios
            </Link>
          </li>
        </ul>
      </nav>
    </header>
  );
};

export default Header;
