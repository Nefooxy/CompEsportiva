import { useEffect, useState } from 'react';
import './Circuito.css';

const Circuito = () => {
    const [duplas, setDuplas] = useState([]);
    const [novoAtleta1, setNovoAtleta1] = useState('');
    const [novoAtleta2, setNovoAtleta2] = useState('');
    const [categoria, setCategoria] = useState('Open');  // Inicialmente a categoria é 'Open'
    const [etapa, setEtapa] = useState('');
    const [pontuacaoAtleta1, setPontuacaoAtleta1] = useState(0);
    const [pontuacaoAtleta2, setPontuacaoAtleta2] = useState(0);
    const [editando, setEditando] = useState(null); // Estado para identificar qual dupla está em edição

    const apiUrl = 'http://localhost:3000/duplas';

    useEffect(() => {
        listarDuplas();
    }, []);

    const listarDuplas = async () => {
        const response = await fetch(apiUrl);
        const data = await response.json();
        setDuplas(data);
    };

    const adicionarDupla = async (e) => {
        e.preventDefault();
        if (!novoAtleta1 || !novoAtleta2) return;

        const response = await fetch(apiUrl, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ atleta1: novoAtleta1, atleta2: novoAtleta2, categoria }),
        });
        if (response.ok) {
            setNovoAtleta1('');
            setNovoAtleta2('');
            setCategoria('Open'); 
            listarDuplas();
        }
    };

    const alterarPontuacao = async (id, novaPontuacaoAtleta1, novaPontuacaoAtleta2) => {
        const response1 = await fetch(`${apiUrl}/${id}/pontuacao`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ atletaNome: 'Atleta 1', etapa, novaPontuacao: novaPontuacaoAtleta1 }),
        });
        const response2 = await fetch(`${apiUrl}/${id}/pontuacao`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ atletaNome: 'Atleta 2', etapa, novaPontuacao: novaPontuacaoAtleta2 }),
        });
        
        if (response1.ok && response2.ok) {
            listarDuplas();
        }
    };

    const editarDupla = async (id) => {
        const atleta1 = prompt('Novo nome do Atleta 1');
        const atleta2 = prompt('Novo nome do Atleta 2');
        const response = await fetch(`${apiUrl}/${id}`, {
            method: 'PATCH',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ atleta1, atleta2 }),
        });
        if (response.ok) {
            listarDuplas();
        }
    };

    const deletarDupla = async (id) => {
        const response = await fetch(`${apiUrl}/${id}`, { method: 'DELETE' });
        if (response.ok) {
            listarDuplas();
        }
    };

    const handleLogout = () => {
        localStorage.removeItem('isAuthenticated');
        localStorage.removeItem('token');
        window.location.href = '/login';
    };

    return (
        <div>
            <button className="sair" onClick={handleLogout}>Sair</button>
            <h1 className="hCircuito">Gerenciamento de Duplas</h1>
            <form className="fCircuito" onSubmit={adicionarDupla}>
                <input
                    id="input-entrada1"
                    type="text"
                    placeholder="Nome do Atleta 1"
                    value={novoAtleta1}
                    onChange={(e) => setNovoAtleta1(e.target.value)}
                />
                <input
                    id="input-entrada"
                    type="text"
                    placeholder="Nome do Atleta 2"
                    value={novoAtleta2}
                    onChange={(e) => setNovoAtleta2(e.target.value)}
                />
                <select onChange={(e) => setCategoria(e.target.value)} value={categoria}>
                    <option value="Open">Open</option>
                    <option value="45+">45+</option>
                </select>
                <button className="add" type="submit">Adicionar</button>
            </form>

            <div className="listaInscritos">
                {duplas.length < 1 ? (
                    <h1 className="hCircuito">Nenhuma Dupla No Sistema</h1>
                ) : (
                    duplas.map((dupla, index) => (
                        <div key={dupla._id} className={dupla.riscada ? "duplaCortada" : "confirmada"}>
                            <span className="Referencia">Atleta 1: {dupla.atleta1.nome}</span>
                            <span className="Referencia">Atleta 2: {dupla.atleta2.nome}</span>
                            <span className="Referencia">Categoria: {dupla.categoria}</span>

                            <div>
                                {editando === index ? (
                                    <div className="edição-container">
                                        <input
                                            id="input-editar"
                                            type="text"
                                            value={dupla.atleta1.nome}
                                            onChange={(e) => setNovoAtleta1(e.target.value)}
                                        />
                                        <input
                                            id="input-editar"
                                            type="text"
                                            value={dupla.atleta2.nome}
                                            onChange={(e) => setNovoAtleta2(e.target.value)}
                                        />
                                        <div className="edição-botões">
                                            <button onClick={() => editarDupla(dupla._id)} className="status">Salvar</button>
                                            <button onClick={() => setEditando(null)} className="del">Cancelar</button>
                                        </div>
                                    </div>
                                ) : (
                                    <div>
                                        <button onClick={() => setEditando(index)} className="edit">Editar Dupla</button>
                                        <button onClick={() => deletarDupla(dupla._id)} className="del">Deletar Dupla</button>
                                    </div>
                                )}
                            </div>

                            <div>
                                <h4>Pontuação por Etapa (Atleta 1):</h4>
                                {dupla.atleta1.pontuacoesPorEtapa.map((pontuacao, idx) => (
                                    <p className="Referencia" key={idx}>Etapa {pontuacao.etapa}: {pontuacao.pontos} pontos</p>
                                ))}
                                <span className="Referencia">Total: {dupla.atleta1.pontuacoesPorEtapa.reduce((total, p) => total + p.pontos, 0)}</span>
                            </div>

                            <div>
                                <h4>Pontuação por Etapa (Atleta 2):</h4>
                                {dupla.atleta2.pontuacoesPorEtapa.map((pontuacao, idx) => (
                                    <p className="Referencia" key={idx}>Etapa {pontuacao.etapa}: {pontuacao.pontos} pontos</p>
                                ))}
                                <span className="Referencia">Total: {dupla.atleta2.pontuacoesPorEtapa.reduce((total, p) => total + p.pontos, 0)}</span>
                            </div>

                            <div className="edição-container">
                                <h4>Alterar Pontuação:</h4>
                                <span className="Referencia">Etapa:</span>
                                <input
                                    type="text"
                                    placeholder="Etapa"
                                    value={etapa}
                                    onChange={(e) => setEtapa(e.target.value)}
                                />
                                <span className="Referencia">Atleta 1:</span>
                                <input
                                    type="number"
                                    placeholder="Pontuação Atleta 1"
                                    value={pontuacaoAtleta1}
                                    onChange={(e) => setPontuacaoAtleta1(e.target.value)}
                                />
                                <span className="Referencia">Atleta 2:</span>
                                <input
                                    type="number"
                                    placeholder="Pontuação Atleta 2"
                                    value={pontuacaoAtleta2}
                                    onChange={(e) => setPontuacaoAtleta2(e.target.value)}
                                />
                                <div>
                                    <button onClick={() => alterarPontuacao(dupla._id, pontuacaoAtleta1, pontuacaoAtleta2)} className="status">Alterar Pontuação</button>
                                </div>
                            </div>
                        </div>
                    ))
                )}
            </div>
        </div>
    );
};

export default Circuito;
