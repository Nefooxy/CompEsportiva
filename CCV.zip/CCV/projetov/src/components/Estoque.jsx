import React from 'react';
import { useNavigate } from 'react-router-dom';
import './Estoque.css';
import Header from './Header';

const Estoque = () => {
  const navigate = useNavigate();


  return (
    <div className="estoque-container">
      <Header /> {}
      <main className="main-contentE">
        <h2>Circuito Campinense de Vôlei de Praia</h2>
        <p>Bem-vindo ao Circuito Campinense de Vôlei de Praia! Estamos empolgados em tê-lo conosco. Esta é a sua central para acompanhar tudo sobre o nosso circuito, desde os rankings e torneios até a galeria de fotos e informações sobre a organização. Com nossa plataforma, você poderá navegar pelas informações e acompanhar as atualizações do circuito de forma simples e rápida. Escolha uma das opções abaixo para explorar:</p>

        {}
        <div className="card-containerE">
          <div className="cardE" onClick={() => navigate('/listar')}>
            <img src="/Imagens/icon 2 rk.png" alt="Ranking" className="card-imageE" />
            <p className="card-textE">Ranking</p>
          </div>
          <div className="cardE" onClick={() => navigate('/torneios')}>
            <img src="/Imagens/torneio.png" alt="Torneios" className="card-imageE" />
            <p className="card-textE">Torneios</p>
          </div>
          <div className="cardE" onClick={() => navigate('/galeria')}>
            <img src="/Imagens/Galeria.png" alt="Galeria" className="card-imageE" />
            <p className="card-textE">Galeria</p>
          </div>
          <div className="cardE" onClick={() => navigate('/organizacao')}>
            <img src="/Imagens/Organizacao.png" alt="Organização" className="card-imageE" />
            <p className="card-textE">Organização</p>
          </div>
        </div>
      </main>
    </div>
  );
};

export default Estoque;
