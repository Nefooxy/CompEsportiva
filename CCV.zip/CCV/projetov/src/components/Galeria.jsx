import React, { useState } from 'react';
import Slider from 'react-slick';
import './Galeria.css';
import Header from './Header';

const Galeria = () => {

  const etapas = [
    {
      titulo: "Etapa 1 - Severino Cabral",
      conteudos: [
        {src: "Imagens/img1-etp1.jpeg" },
        {src: "Imagens/img2-etp1.jpeg" },
        {src: "Imagens/img3-etp1.jpeg" },
        {src: "Imagens/img4-etp1.jpeg" },
        {src: "Imagens/img5-etp1.jpeg" },
        {src: "Imagens/img6-etp1.jpeg" },
        {src: "Imagens/img7-etp1.jpeg" },
        {src: "Imagens/img8-etp1.jpeg" },
        {src: "Imagens/img9-etp1.jpeg" },
        {src: "Imagens/img10-etp1.jpeg" },
        {src: "Imagens/img11-etp1.jpeg" },
        {src: "Imagens/img12-etp1.jpeg" },
        {src: "Imagens/img13-etp1.jpeg" },
        {src: "Imagens/img14-etp1.jpeg" },
        {src: "Imagens/img15-etp1.jpeg" },
        {src: "Imagens/img16-etp1.jpeg" },

      ],
    },
    {
      titulo: "Etapa 2 - Arena Andrey",
      conteudos: [
        {src: "Imagens/img1-etp2.jpeg" },
        {src: "Imagens/img2-etp2.jpeg" },
        {src: "Imagens/img3-etp2.jpeg" },
        {src: "Imagens/img4-etp2.jpeg" },
        {src: "Imagens/img5-etp2.jpeg" },
        {src: "Imagens/img6-etp2.jpeg" },
        {src: "Imagens/img7-etp2.jpeg" },
        {src: "Imagens/img8-etp2.jpeg" },
        {src: "Imagens/img9-etp2.jpeg" },
      ],
    },
    {
      titulo: "Etapa 3 - Severino Cabral",
      conteudos: [
        {src: "Imagens/img1-etp3.jpeg" },
        {src: "Imagens/img2-etp3.jpeg" },
        {src: "Imagens/img3-etp3.jpeg" },
        {src: "Imagens/img4-etp3.jpeg" },
        {src: "Imagens/img5-etp3.jpeg" },
        {src: "Imagens/img6-etp3.jpeg" },
        {src: "Imagens/img7-etp3.jpeg" },
        {src: "Imagens/img8-etp3.jpeg" },
        {src: "Imagens/img9-etp3.jpeg" },
        {src: "Imagens/img10-etp3.jpeg" },
        {src: "Imagens/img11-etp3.jpeg" },
        {src: "Imagens/img12-etp3.jpeg" },
        {src: "Imagens/img13-etp3.jpeg" },
        {src: "Imagens/img14-etp3.jpeg" },
        {src: "Imagens/img15-etp3.jpeg" },
        {src: "Imagens/img16-etp3.jpeg" },
        {src: "Imagens/img17-etp3.jpeg" },
        {src: "Imagens/img18-etp3.jpeg" },
        {src: "Imagens/img19-etp3.jpeg" },
        {src: "Imagens/img20-etp3.jpeg" },
        {src: "Imagens/img21-etp3.jpeg" },
        {src: "Imagens/img22-etp3.jpeg" },
        {src: "Imagens/img23-etp3.jpeg" },
        {src: "Imagens/img24-etp3.jpeg" },
        {src: "Imagens/img25-etp3.jpeg" },
      ],
    },
  ];

  const [expandedImage, setExpandedImage] = useState(null);

  const settings = {
    dots: true,
    infinite: true,
    speed: 500,
    slidesToShow: 1,
    slidesToScroll: 1,
    responsive: [
      {
        breakpoint: 1024,
        settings: {
          slidesToShow: 1,
          slidesToScroll: 1,
        },
      },
      {
        breakpoint: 768,
        settings: {
          slidesToShow: 1,
          slidesToScroll: 1,
        },
      },
      {
        breakpoint: 480,
        settings: {
          slidesToShow: 1,
          slidesToScroll: 1,
        },
      },
    ],
  };

  const handleImageClick = (src) => {
    setExpandedImage(src);
  };

  const closeModal = () => {
    setExpandedImage(null);
  };

  return (
    <div className="galeria-container">
        <Header /> {}
        <h1>Galeria de Fotos</h1>

      <main className="main-contentG">
        <p className="explicacao">
          Aqui você poderá acompanhar todos os registros das etapas que já ocorreram.
        </p>

        <div className="etapas-container">
          {etapas.map((etapa, index) => (
            <div key={index} className="etapa">
              <h2 className="etapa-titulo">{etapa.titulo}</h2>
              <Slider {...settings} className="etapa-slider">
                {etapa.conteudos.map((conteudo, idx) => (
                <div key={idx} className="etapa-conteudo">
                    <div className="cardG" onClick={() => handleImageClick(conteudo.src)}>
                      <img src={conteudo.src} alt={`Etapa ${index + 1} Imagem ${idx + 1}`} />
                    </div>
                  </div>
                ))}
              </Slider>
            </div>
          ))}
        </div>

        {}
        {expandedImage && (
          <div className="modal" onClick={closeModal}>
            <div className="modal-content">
              <span className="close" onClick={closeModal}>&times;</span>
              <img src={expandedImage} alt="Imagem expandida" className="expanded-image" />
            </div>
          </div>
        )}
      </main>
    </div>
  );
};

export default Galeria;
