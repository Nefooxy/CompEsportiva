const express = require('express');
const Dupla = require('../models/dupla');
const router = express.Router();

router.post('/', async (req, res) => {
    const { atleta1, atleta2, categoria } = req.body;

    if (!atleta1 || !atleta2 || !categoria) {
        return res.status(400).json({ message: 'Atletas e categoria são obrigatórios' });
    }

    try {
        const novaDupla = new Dupla({
            atleta1: { nome: atleta1, pontuacaoAcumulada: 0 },
            atleta2: { nome: atleta2, pontuacaoAcumulada: 0 },
            categoria
        });

        await novaDupla.save();
        res.status(201).json(novaDupla);
    } catch (error) {
        console.error('Erro ao criar a dupla:', error);
        res.status(500).json({ message: 'Erro ao criar a dupla' });
    }
});

router.get('/', async (req, res) => {
    const { etapa, categoria } = req.query; 

    try {
        const duplas = await Dupla.find();

        let duplasFiltradas = duplas;
        if (categoria) {
            duplasFiltradas = duplasFiltradas.filter(dupla => dupla.categoria === categoria);
        }

        const duplasComPontuacao = duplasFiltradas.map(dupla => {
            const somaPontuacoesAtleta1 = dupla.atleta1.pontuacoesPorEtapa.reduce((total, p) => total + p.pontos, 0);
            const somaPontuacoesAtleta2 = dupla.atleta2.pontuacoesPorEtapa.reduce((total, p) => total + p.pontos, 0);

            const pontuacaoTotal = somaPontuacoesAtleta1 + somaPontuacoesAtleta2;

            return {
                ...dupla.toObject(),
                pontuacaoTotal,
                pontuacoesAtleta1: dupla.atleta1.pontuacoesPorEtapa,
                pontuacoesAtleta2: dupla.atleta2.pontuacoesPorEtapa
            };
        });

        if (etapa) {
            const duplasPorEtapa = duplasComPontuacao.map(dupla => {
                const pontuacaoEtapaAtleta1 = dupla.atleta1.pontuacoesPorEtapa.find(p => p.etapa === etapa)?.pontos || 0;
                const pontuacaoEtapaAtleta2 = dupla.atleta2.pontuacoesPorEtapa.find(p => p.etapa === etapa)?.pontos || 0;
                
                const pontuacaoTotalEtapa = pontuacaoEtapaAtleta1 + pontuacaoEtapaAtleta2;

                return {
                    ...dupla,
                    pontuacaoTotalEtapa
                };
            });

            return res.status(200).json(duplasPorEtapa.sort((a, b) => b.pontuacaoTotalEtapa - a.pontuacaoTotalEtapa));
        }

        const duplasOrdenadas = duplasComPontuacao.sort((a, b) => b.pontuacaoTotal - a.pontuacaoTotal);

        res.status(200).json(duplasOrdenadas);
    } catch (error) {
        console.error('Erro ao listar as duplas:', error);
        res.status(500).json({ message: 'Erro ao listar as duplas' });
    }
});

router.patch('/:id', async (req, res) => {
    const { atleta1, atleta2 } = req.body;

    if (!atleta1 || !atleta2) {
        return res.status(400).json({ message: 'Ambos os atletas são necessários para edição.' });
    }

    try {
        const dupla = await Dupla.findByIdAndUpdate(req.params.id, {
            atleta1: { nome: atleta1 },
            atleta2: { nome: atleta2 }
        }, { new: true });

        if (!dupla) {
            return res.status(404).json({ message: 'Dupla não encontrada' });
        }

        res.status(200).json(dupla);
    } catch (error) {
        console.error('Erro ao editar a dupla:', error);
        res.status(500).json({ message: 'Erro ao editar a dupla' });
    }
});

router.put('/:id/pontuacao', async (req, res) => {
    const { atletaNome, etapa, novaPontuacao } = req.body;

    if (!atletaNome || !etapa || novaPontuacao === undefined) {
        return res.status(400).json({ message: 'Atleta, etapa e nova pontuação são obrigatórios' });
    }

    try {
        const dupla = await Dupla.findById(req.params.id);
        if (!dupla) {
            return res.status(404).json({ message: 'Dupla não encontrada' });
        }

        const atleta = atletaNome === 'Atleta 1' ? dupla.atleta1 : atletaNome === 'Atleta 2' ? dupla.atleta2 : null;
        if (!atleta) {
            return res.status(400).json({ message: 'Nome do atleta inválido' });
        }

        const existingEtapa = atleta.pontuacoesPorEtapa.find((p) => p.etapa === etapa);
        if (existingEtapa) {
            existingEtapa.pontos = novaPontuacao;
        } else {
            atleta.pontuacoesPorEtapa.push({ etapa, pontos: novaPontuacao });
        }

        await dupla.save();
        res.status(200).json(dupla);
    } catch (error) {
        console.error('Erro ao alterar pontuação:', error);
        res.status(500).json({ message: 'Erro ao alterar pontuação' });
    }
});

router.delete('/:id', async (req, res) => {
    try {
        const dupla = await Dupla.findByIdAndDelete(req.params.id);
        if (!dupla) {
            return res.status(404).json({ message: 'Dupla não encontrada' });
        }

        res.status(200).json({ message: 'Dupla deletada com sucesso' });
    } catch (error) {
        console.error('Erro ao deletar a dupla:', error);
        res.status(500).json({ message: 'Erro ao deletar a dupla' });
    }
});

module.exports = router;
