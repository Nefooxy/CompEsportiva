const mongoose = require('mongoose');

const atletaSchema = new mongoose.Schema({
    nome: { type: String, required: true },
    pontuacoesPorEtapa: [{ etapa: String, pontos: Number }] 
});

const duplaSchema = new mongoose.Schema({
    atleta1: atletaSchema,
    atleta2: atletaSchema,
    categoria: { type: String, required: true },
});

const Dupla = mongoose.model('Dupla', duplaSchema);
module.exports = Dupla;
